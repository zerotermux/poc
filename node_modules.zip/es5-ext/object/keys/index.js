"use strict";

module.exports = require("./is-implemented")() ? Object.keys : require("./shim");
