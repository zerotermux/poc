"use strict";

module.exports = { asCallback: require("./as-callback"), finally: require("./finally") };
