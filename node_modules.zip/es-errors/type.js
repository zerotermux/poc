'use strict';

/** @type {import('./type')} */
module.exports = TypeError;
